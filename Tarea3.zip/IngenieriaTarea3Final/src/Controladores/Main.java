/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Controladores.*;
import javax.swing.JOptionPane;
import java.util.*;
import java.text.*;


/**
 * 
 *
 * @author arturo
 */
public class Main {
    
    public static void main(String[] args) {
        
                
        
        ControladorFacturas Factura = new ControladorFacturas();
        
        Factura.ImprimirFactura(74223);
         
         
    }

        
}
